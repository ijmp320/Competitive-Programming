#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
#define FOR(i,a,n) for(int i=a;i<(int)(n);i++)
#define REP(i,n) FOR(i,0,n)
#define ALL(a) (a).begin(),(a).end()
#define MP(a,b) make_pair(a,b)
#define PB(a) push_back(a)
#define F first
#define S second
const int INF = 2000000000;
const int DX[4]={0,1,0,-1}, DY[4]={-1,0,1,0};
struct P{int x;int y;P(int X=0,int Y=0){x=X;y=Y;}};

template < class BidirectionalIterator >
bool next_combination ( BidirectionalIterator first1 ,
  BidirectionalIterator last1 ,
  BidirectionalIterator first2 ,
  BidirectionalIterator last2 )
{
  if (( first1 == last1 ) || ( first2 == last2 )) {
    return false ;
  }
  BidirectionalIterator m1 = last1 ;
  BidirectionalIterator m2 = last2 ; --m2;
  while (--m1 != first1 && !(* m1 < *m2 )){
  }
  bool result = (m1 == first1 ) && !(* first1 < *m2 );
  if (! result ) {
    // ①
    while ( first2 != m2 && !(* m1 < * first2 )) {
      ++ first2 ;
    }
    first1 = m1;
    std :: iter_swap (first1 , first2 );
    ++ first1 ;
    ++ first2 ;
  }
  if (( first1 != last1 ) && ( first2 != last2 )) {
    // ②
    m1 = last1 ; m2 = first2 ;
    while (( m1 != first1 ) && (m2 != last2 )) {
      std :: iter_swap (--m1 , m2 );
      ++ m2;
    }
    // ③
    std :: reverse (first1 , m1 );
    std :: reverse (first1 , last1 );
    std :: reverse (m2 , last2 );
    std :: reverse (first2 , last2 );
  }
  return ! result ;
}

template < class BidirectionalIterator >
bool next_combination ( BidirectionalIterator first ,
  BidirectionalIterator middle ,
  BidirectionalIterator last )
{
  return next_combination (first , middle , middle , last );
}

template<class TYPE>
class RepeatedCombinationGenerator {
private:
    std::vector<TYPE> data_;
    unsigned int select_;   // 選択する数
public:
    // コンストラクタ
    template<class InputIterator>
    RepeatedCombinationGenerator(InputIterator begin, InputIterator end, const unsigned int n){
        select_ = n;
        // 重複する値を取り除く
        std::set<TYPE> s;
        for(InputIterator iter=begin; iter!=end; ++iter){
            s.insert(*iter);
        }
        // 選択可能な値をn個ずつ持つ配列を作成
        data_.clear();
        for(auto iter=s.begin(); iter!=s.end(); ++iter){
            for(unsigned int i=0; i<n; ++i){
                data_.push_back(*iter);
            }
        }
    }
    // 最初の組み合わせの生成
    void fast(){
        std::sort(data_.begin(), data_.end());
    }
    // 最後の組み合わせの生成
    void last(){
        std::sort(data_.begin(), data_.end());
        std::vector<TYPE> new_data;
        std::back_insert_iterator<std::vector<TYPE> > iter(new_data);
        std::copy(data_.end()-select_, data_.end(), iter);
        std::copy(data_.begin(), data_.end()-select_, iter);
        data_ = new_data;
    }
    // 次の組み合わせの生成
    bool next(){
        return next_combination(data_.begin(), data_.begin()+select_, data_.end());
    }
    // 前の組み合わせの生成
    bool prev(){
        return prev_combination(data_.begin(), data_.begin()+select_, data_.end());
    }
    // 現在の組み合わせを取得
    std::vector<TYPE> data() const{
      return std::vector<TYPE>(data_.begin(), data_.begin()+select_);
    }
    // 全ての重複組み合わせの数
    unsigned int size() const{
        unsigned int n = data_.size() / select_;
        unsigned int r = select_;
        return factorial(n+r-1, n-1)/factorial(r);
    }
private:
    // 階乗
    unsigned int factorial(const unsigned int max, const unsigned int min = 1) const{
        unsigned int result = 1;
        for(unsigned int i=min+1; i<=max; ++i){
            result *= i;
        }
        return result;
    }
};

// Problem B

int main() {
    int T;
    cin >> T;
    REP(t,T) {
        int K,L,S;
        double ans=0;
        string key,tar;
        cin >> K >> L >> S >> key >> tar;

        vector<int> s(K);
        REP(i,K) s[i] = i;

        int count = 0;
        RepeatedCombinationGenerator<int> g(ALL(s), S);
        do{
            std::vector<int> data = g.data();
            string str;
            REP(i,S) {
                str.PB(key[data[i]]);
            }
            cout << str << endl;
            count++;
        }while(g.next());

        printf("Case #%d: %f\n",t+1, ans);
    }
    return 0;
}
