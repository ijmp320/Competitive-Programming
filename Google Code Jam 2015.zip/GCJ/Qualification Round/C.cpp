#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
#define FOR(i,a,n) for(int i=a;i<(int)(n);i++)
#define REP(i,n) FOR(i,0,n)
#define ALL(a) (a).begin(),(a).end()
#define MP(a,b) make_pair(a,b)
#define PB(a) push_back(a)
#define F first
#define S second
const int INF = 2000000000;
const int DX[4]={0,1,0,-1}, DY[4]={-1,0,1,0};
struct P{int x;int y;P(int X=0,int Y=0){x=X;y=Y;}};

struct ch {
	bool nega;
	char c;
	ch():nega(false),c('#') {}
	ch(bool b, char cha) {
		nega = b;
		c = cha;
	}
};

ch getStr(vector<ch> v) {
	stack<ch> st;
	REP(i,v.size()) {
		st.push(v[i]);
	}
	while(!st.empty()) {
		if(st.size() == 1) {
			ch c1 = st.top(); st.pop();
			return c1;
		}
		ch c2 = st.top(); st.pop();
		ch c1 = st.top(); st.pop();
		ch cn;
		cn.nega = (c2.nega != c1.nega);
		if(c1.c=='1' && c2.c=='1') {cn.c = '1';}
		if(c1.c=='1' && c2.c=='i') {cn.c = 'i';}
		if(c1.c=='1' && c2.c=='j') {cn.c = 'j';}
		if(c1.c=='1' && c2.c=='k') {cn.c = 'k';}
		if(c1.c=='i' && c2.c=='1') {cn.c = 'i';}
		if(c1.c=='i' && c2.c=='i') {cn.c = '1'; cn.nega=!cn.nega;}
		if(c1.c=='i' && c2.c=='j') {cn.c = 'k';}
		if(c1.c=='i' && c2.c=='k') {cn.c = 'j'; cn.nega=!cn.nega;}
		if(c1.c=='j' && c2.c=='1') {cn.c = 'j';}
		if(c1.c=='j' && c2.c=='i') {cn.c = 'k'; cn.nega=!cn.nega;}
		if(c1.c=='j' && c2.c=='j') {cn.c = '1'; cn.nega=!cn.nega;}
		if(c1.c=='j' && c2.c=='k') {cn.c = 'i';}
		if(c1.c=='k' && c2.c=='1') {cn.c = 'k';}
		if(c1.c=='k' && c2.c=='i') {cn.c = 'j';}
		if(c1.c=='k' && c2.c=='j') {cn.c = 'i'; cn.nega=!cn.nega;}
		if(c1.c=='k' && c2.c=='k') {cn.c = '1'; cn.nega=!cn.nega;}
		st.push(cn);
	}
}

int main() {
	int T;
	cin >> T;
	REP(t,T) {
		int L,X;
		string s;
		cin >> L >> X >> s;
		string tmp="";
		REP(i,X) tmp += s;
		s = tmp;
		int len = L*X;

		if(len<3) {
			printf("Case #%d: NO\n",t+1);
			continue;
		}



		vector<ch> s1,s2,s3;
		for(int i=0; i<len-2; i++) {
			s1.PB(ch(false, s[i]));
			for(int j=i+1; j<len-1; j++) {
				s2.PB(ch(false, s[j]));
				for(int k=j+1; k<len; k++) {
					s3.PB(ch(false, s[k]));
				}

				bool bi=false,bj=false,bk=false;
				ch ch1 = getStr(s1);
				ch ch2 = getStr(s2);
				ch ch3 = getStr(s3);
				if(ch1.c == 'i' && !ch1.nega) bi = true;
				if(ch2.c == 'j' && !ch2.nega) bj = true;
				if(ch3.c == 'k' && !ch3.nega) bk = true;
				if(bi && bj && bk) {
					printf("Case #%d: YES\n",t+1);
					goto next;
				}
				s3.clear();
			}
			s2.clear();
		}
		printf("Case #%d: NO\n",t+1);
		next:;
	}
	return 0;
}

