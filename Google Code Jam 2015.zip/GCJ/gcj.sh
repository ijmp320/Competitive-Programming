g++ -std=c++11 -O2 source.cpp

(./a.out < A-small-attempt0.in) > out.txt
